var intro = ">>> Ola seja bem vindo a Rifa online <<<";
console.log(intro);

console.log('Lista de premios');

const premios = [
  'Xox Series X',
  'PC Gamer',
  'Iphone 11',
];

let index = 0;

while (index < premios.length) {
  console.log(index, premios[index]);
  index++;
}

console.log('=============');

var regras = 'Escolha um numero de 1 a 20 :)';
console.log(regras);

console.log('Numeros Escolhidos !!!');

let escolhidos = [4,7,10,13,15]

for (let valor of escolhidos) {
  console.log(valor);
}

console.log('=============');

var nomecompleto = prompt('Qual o seu nome ?')

var idade = prompt('Qual a sua idade ?')

var cpf = '';

do{
  cpf = prompt ('Qual o numero so seu CPF ?');

  if (cpf.length == 11)
    alert ('CPF valido..');
  else
  alert('CPF invalido, tente novamente !!!');

}while (cpf.length !== 11);

if(idade >= 18){
  console.log('Ok idade Perimitida');
}else{
  console.log('Necessario ser maior de 18');
}

console.log('=============');

var pessoa =nomecompleto;
console.log("Ola seja muito bem vindo",pessoa);

var sorte = prompt('Escolha o seu numero da sorte de 1 a 20')
switch (sorte) {
  case '1':
  case '2':
  case '3':
  case '5':
  case '6':
  case '8':
  case '9':
  case '11':
  case '12':
  case '14':
  case '16':
  case '17':
  case '18':
  case '19':
  case '20':
      alert('O seu numero da sorte é o',sorte);
      break;
  case '0':
  default:
      alert('Numero invalido :(');
}
Math.floor(Math.random()* (20 - 1 + 1)) + 1

console.log('o numero sorteado foi',Math.floor(Math.random()* (20 - 1 + 1)) + 1);

if(sorte == Math.floor(Math.random()* (20 - 1 + 1)) + 1){
  console.log('Parabens você ganhou');
}else{
  console.log('infelizmente voce perdeu');
}
